package assignment5;

public class A5driver {

	 public static void main(String[] args) {
	        FindLadder finder = new FindLadder("assn1words.dat", 5);
	        finder.generateLadder("stone", "money");
	        finder.generateLadder("hello", "world");
	        finder.generateLadder("world", "hello");
	        finder.generateLadder("heads", "tails");
	      
	    }
	
}
