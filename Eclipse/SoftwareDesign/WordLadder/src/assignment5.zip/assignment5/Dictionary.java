package assignment5;
import java.io.*;
import java.util.HashSet;

public class Dictionary {
	
	private HashSet<String> wordList;
	int length;
	
	public Dictionary(int wordLength) throws IOException{
		wordList = new HashSet<String>();
		length = wordLength;
		FileReader infile = new FileReader("assn5words.dat");
		BufferedReader br = new BufferedReader(infile);
		String s = br.readLine();
		while(s != null){
			wordList.add(s.substring(0,5));
			s = br.readLine();
		}
		br.close();
	}
	
	public boolean contains(String searchWord){
		return wordList.contains(searchWord);
	}
	
	public void addWord(String newWord){
		if(newWord.length() == length && newWord.startsWith("*")==false)
			wordList.add(newWord);
	}
	
	public int length(){
		return wordList.size();
	}
}
