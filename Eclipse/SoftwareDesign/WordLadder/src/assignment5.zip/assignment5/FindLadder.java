package assignment5;
import java.util.*;
import java.io.*;

public class FindLadder {
    final int length;
    Dictionary dict;
    PriorityQueue<String> nextWord;
    String[] ladder;
    int ladderIndex;
    int treshold;
    int count;
    ArrayList<String> solution;
    HashSet<String> visited;
    
    public FindLadder(String dictName, int wordLength) {
    	try{
    		dict = new Dictionary(5);
    	}
    	
    	catch (java.io.FileNotFoundException e){
    		System.out.println("DICTIONARY FILE NOT FOUND");
    	} 
    	catch (IOException e) {
			// TODO Auto-generated catch block
    		System.out.println("IO Exception");
			e.printStackTrace();
		}
    	
    	length = wordLength;
    	treshold = 100;
    	
    } 
    
	public void generateLadder(String begin, final String end) {
		nextWord = new PriorityQueue<String>(100,
				new Comparator<String>( ) {
    				public int compare(String i, String j) {
    					int diffA = strComparer(i, end);
    					int diffB = strComparer(j, end);
    					
    					if(diffA == diffB)
    						return 0;
    					
    					if(diffA < diffB) //i is closer to the end
    						return -1;
    					else //j is closer to the end
    						return 1;
    				}
    		}
		);
		
		visited = new HashSet<String>();
		solution = new ArrayList<String>();
		nextWord.add(begin);
		visited.add(begin);
		count = 0;
		try{
			boolean a =(depthFirstSearch(begin, end, 0));
			if(a){
				System.out.println("Solution Found!");
				String b = "[";
				for(int i = 0; i < solution.size(); i++){
					b+= (solution.get(i) + ", ");
				}
				System.out.println(b+ end+ "]");
			}
			else
				System.out.println("No solution found.");
		}
		catch(StackOverflowError e){
			System.out.println(e + "Reached treshold of " + treshold + " recursive depth.");
		}
	}
    
    boolean depthFirstSearch(String begin, String end, int change){
    	if(strComparer(begin, end) == 1){
    		solution.add(begin);
    		return true;
    	}
    	
    	if(count > treshold)
    		throw new StackOverflowError();
      	
    	if(change >= length){
    		nextWord.remove(begin);
    		return false;
    	}

    	for(char a = 'a'; a!= 'z'; a++){
	    	String newWord = begin.substring(0, change) + a + begin.substring(change+1);
	    	if(dict.contains(newWord) && !visited.contains(newWord) && !nextWord.contains(newWord))
	    		nextWord.add(newWord);
	   	}
    	
    	if(count<=5){
    		count++;
    		if(depthFirstSearch(begin, end, change+1))
    			return true;
    	}
	    count = 0;
	   	if(nextWord.isEmpty())
	   		return false;

	   	count++;
	   	visited.add(nextWord.peek());
	   	solution.add(begin);
	   	return depthFirstSearch(nextWord.remove(), end, 0);
    }
    
    private int strComparer(String a, String b){
        int diffCount = 0;
 	    for (int i = 0; i < a.length(); i++) {
 		    if (a.charAt(i) != b.charAt(i)) {
 			    diffCount++;
 		    }
 	    }
 	    return diffCount;
    }
}
