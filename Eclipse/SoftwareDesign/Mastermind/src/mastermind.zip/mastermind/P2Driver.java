/**
Date: Feb 17, 2013
Student Name: Nikhil Joglekar
EID: nrj328
Student Name: Anirudh Kashyap
EID: ak22564
Lab Session: 5
 */
package mastermind;
//The Main 
public class P2Driver 
{
	public static void main(String[] args) 
	{	
		Game newGame = new Game(true);
		newGame.run();
	}

}
