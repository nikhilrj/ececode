package assignment1;
/**
Date: Feb 1, 2013
Student Name: Nikhil Joglekar
EID: nrj328
Lab Session: Monday 5:00-6:30PM
 */

import java.io.*;
public class A1Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws IOException {
		Palindrome a = new Palindrome();
		a.palRunner();
	}

}
